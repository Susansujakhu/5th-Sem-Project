    	<div class="topright">
        	<a href="../project">  Home </a>
        	<a href="service.php">  Services </a>
        	<a href="products.php">  Products </a>
        	<a href="aboutus.php">  About Us </a> 
		</div>