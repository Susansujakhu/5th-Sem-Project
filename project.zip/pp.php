	<img src="theheart.jpg">
<br>
<br>
<br>
<br>
<br>
	<img src="doc_brain.jpg">
<br>
<br>
<br>
<br>
<br>
    <img src="Pediatric.jpg">
<br>
<br>
<br>
<br>
<br>
	<img src="Orthopaedic.jpg">
<br>
<br>
<br>
<br>
<br>
	<img src="electrotherapy.jpg">
<br>
<br>
<br>
<br>
<br>

	<img src="Ergonomics.jpg">
<br>
<br>
<br>
<br>
<br>
    <img src="exercise.jpg">	
</center> </div>	
	<div style="margin-left: 25%" class="lab" >

<b>	<label  style="color: brown" > CARDIOLOGY </label> </b><br><br> 

	 <span class="description">
Cardiac rehab is a medically supervised program designed to improve your cardiovascular health if you have experienced heart attack, heart failure, angioplasty or heart surgery. Cardiac rehab has three equally important parts: exercise counseling and training, education for heart-healthy living, counseling to reduce stress. 
</span>
</div>
	
<div class="head">
	<b>	NEUROLOGY </b><br><br>
		<span class="description">

Common types of impairments associated with neurologic conditions can include balance, vision, ambulation, movement, activities of daily living, speech, or loss of functional independence.Neurological Reparative Therapy (NRT) is a new model of treatment on how to better the lives of individuals who suffer from a wide range of mental, emotional, and behavioral disturbances - particularly children and adolescents.
</span></div> 

<div class="head">
<b>	PEDIACTRICS </b><br><br>
		<span class="description">
Pediatric physiotherapy is a broad term for the treatment of babies, toddlers, children, and youth from 0-18 years of age by specially trained therapists.Following our assessment of your child’s condition, a personalized treatment plan will be created specifically for them. This treatment plan will involve hands-on treatment on behalf of our physiotherapist as well as exercises and activities to perform at home.
</span> </div>

<div class="head">
<b>	ORTHOPEDICS </b><br><br>
		<span class="description">
This is the branch of physiotherapy concerned with the treatment of injuries or disorders of the skeletal system and associated muscles, joints and ligaments Orthopaedic Physiotherapy also includes pre and post operative rehabilitation of hip, shoulder and knee. Orthopaedic Physiotherapy is a scientific approach to treatment following Evidence Based Guidelines. 
</span>
  </div>
	
<div class="head">
	<b>	ELECTROTHERAPY </b><br><br>
		<span class="description">
TENS AND ULTRASOUND <BR>
Our Physios use electrotherapy to treat disorders relating to the muscles, ligaments and/or bone.  The Physiotherapist will use modalities to compliment the manual and exercise treatment being prescribed to aid recovery  as needed. 
</span>
 </div>
	
<div class="head">
	<b>	ERGONOMICS </b><br><br>
		<span class="description">
Ergonomics is employed to fulfill the two goals of health and productivity.The scientific discipline concerned with the understanding of interactions among humans and other elements of a system, and the profession that applies theory, principles, data and methods to design in order to optimize human well-being and overall system performance.
</span>  
</div>
	
<div class="head">
	<b>	EXERCISE PLAN </b><br><br>
		<span class="description">
Many people begin their exercise routines with intentions of getting stronger, losing weight and improving health, but wind up disappointed when they lose willpower and commitment. Physiotherapy can help you develop a routine you can stick to!If you're struggling to establish and maintain a regular exercise routine, you're not alone! We all face commitment difficulties in life, and need some outside help from time to time.
</span>  </div>