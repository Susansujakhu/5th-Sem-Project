<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
</head>
<body>
<form action="" method="post">
	<div class="logout">
	<?php
	$user=$_SESSION['uname'];
	echo "Welcome ".$user;
	?>
	<input class="btn" type="submit" name="logout" value="Logout">
	</div>
</form>
</body>
</html>
<?php
//session_start();
if (isset($_POST['logout'])) {
	session_destroy();
 	header('location:./');
}

?>