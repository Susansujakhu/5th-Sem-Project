
<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
	<link type="text/css" rel="stylesheet" href="style.css" >
		<script type="text/javascript">
		function call(){
			var email=document.getElementById('email').value;
			var check = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
 			 if(!check.test(email)){
 			document.getElementById("error").innerHTML="**Invalid Email**";
 			return false;
 			 } 
			}
			
	</script>
</head>
<body>
	
<div class="contain">

		<?php
		include 'menu.php';
		session_start();
		if(isset($_SESSION['uname']))
		{
    //  logged in
    		include 'ulogout.php';

    	}
    	else{
    		include 'ulogin.php';
    	}
		?>



<br><br>
    <div class="fig">
   	<center><img src="physiotherapy_home.png">	</center>
   	</div>

  <div class="heads">
    &nbsp Physiotherapy
  </div>

<div class="marq">
<?php
include 'connect.php';
	$sql="SELECT * FROM notice";
	$result=mysqli_query($con,$sql);
	echo '<marquee behavior="scroll" direction="left" onmouseover="stop()" onmouseout="start()">';
	while($row = mysqli_fetch_array($result)) {
        echo  $row['N_ID'].". ".$row['Notice']."  |";
    }

echo '</marquee>';
mysqli_close($con);
?>
</div>
<br> <br>
<?php
include 'connect.php';
$count = mysqli_query($con,"SELECT * FROM home");
$num = mysqli_num_rows($count);
$i=1;
while ($num!=0) {
	
echo "<span class='heading'>";
	$sql="SELECT Title FROM home WHERE SN=$i";
	$result=mysqli_query($con,$sql);
	while($row = mysqli_fetch_array($result)) {
        echo  $row['Title'];
    }
echo "</span><p>";
	$sql1="SELECT * FROM home WHERE SN=$i";
	$result1=mysqli_query($con,$sql1);
	while($row1 = mysqli_fetch_array($result1)) {
        //echo $row1['Para 1'];
        echo nl2br(nl2br($row1['Para 1']));
        //echo "<p>".$row1['Para 2']."</p>";
        //echo "<p>".$row1['Para 3']."</p>";
        //echo "<p>".$row1['Para 4']."</p>";
       // echo "<p>".$row1['Para 5']."</p>";
    
    }
    echo "</p>";

$i=$i+1;
$num=$num-1;
}

echo "<br>";
mysqli_close($con);
?>

<img src="images/1.jpg" height=30% width=30%>
<img src="images/4.png" height=45% width=45%>
<img src="images/3c.jpg" height="20%" width="20%">
<hr>
	<form method="post" action="">
	
	<div class="feed">Feedback</div> 

	<b class="feedback">Email:</b>
	<input style="font-size: 19px; color:purple;" type="text" name="email" id="email" size="50px" required>
	<span id="error" style="color:red"></span>
	<br>
	
	<textarea  class="feedback" name="feed" rows=4 cols="112" placeholder="Your Text Here" required></textarea>
	<br>
	<span id="feed_error" style="color:red; margin-left: 8%"></span>
	 <br><br>
	<input style="font-size: 19px; color:#660033; margin-left: 8%" type="submit" name="sub" value="Submit" onclick="return call()">

	</form>

	<hr>
	<footer>
		<center>
		COPYRIGHT © 2015 BHDC<br><br>
THE CONTENT PROVIDED ON THIS WEBSITE IS PRESENTED OR COMPILED FOR YOUR CONVENIENCE BY BHDC AND IS PROVIDED FOR INFORMATIONAL PURPOSES ONLY. THE INFORMATION PROVIDED SHOULD NOT BE CONSTRUED AS OFFERING MEDICAL ADVICE. YOU SHOULD SEEK PHYSIOTHERAPY OR MEDICAL CARE IMMEDIATELY FOR ANY SPECIFIC HEALTH ISSUES. USE OF THIS WEBSITE IS SUBJECT TO BHDC TERMS OF SERVICE.
	</center></footer>
</div>

</div>
</body>
</html>

<?php
include 'connect.php';
if(isset($_POST['sub'])){
	$email=$_POST['email'];
	$feed=$_POST['feed'];
	date_default_timezone_set('America/Chicago'); // CDT
$info = getdate();
$date = $info['mday'];
$month = $info['mon'];
$year = $info['year'];

$datee = "$year/$month/$date";

$sql="INSERT INTO `feedback`(`Email`, `Feedback`, `Checked`, `Date`) VALUES ('$email','$feed','1','$datee')";

if(mysqli_query($con,$sql)){
	echo "<script type='text/javascript'>";
	echo "alert('Thankyou For The Feedback')";
	echo "</script>";
mysqli_close($con);
}
else{
	$err=mysqli_error($con);
	echo "<script type='text/javascript'>";
	echo "alert('Failed To send Feedback')";
	echo "</script>";
}
}
?>