
<!DOCTYPE html>
<html>
<head>
	<title>Contact page</title>
 <style>

.image{
	float: left;

	margin-left: 100px;
	color:black;
	font-family: monospace;
}
.detail{
	margin-top: 10px;
	margin-left: 35%;
	color: brown;
	font-size: 30px;
	font-family: monospace;

}
.background {
	 overflow: scroll;
	margin-top: 57px;
  background: url(cont1.png);
  background-size: cover;
  position: fixed; 

  width: 100%;
  height:100%;
}

.mail{
	float: left;
}
h1{
	font-size: 35px;
	color: gray;
}

</style>
	<link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>

        <?php
        include 'menu.php';
        session_start();
        if(isset($_SESSION['uname']))
        {
    //  logged in
            include 'ulogout.php';

        }
        else{
            include 'ulogin.php';
        }
        ?>

  <div class="background">
	
	   
    <br><br>
	   <div class="image">
        	<?php
        			include 'connect.php';
        			$count = mysqli_query($con,"SELECT * FROM aboutus");
					$num =mysqli_num_rows($count);
                    
					$i=1;
					while ($num!=0) {
        			$sql="SELECT * FROM `aboutus` WHERE ID=$i";
        			$result = mysqli_query($con,$sql) or die("Error: " . mysqli_error($con));
        			while($row = mysqli_fetch_array($result)) {
        				$image=$row['image'];
        				echo "<img style='border-radius: 50%' src=$image height='250px' width='250px'>";
        				
        				echo "<br><br><br><br>";
        			}
        			$i=$i+1;
        			$num=$num-1;
        		}
        			mysqli_close($con)
        		?>
        	</div>
        	<div class="detail">
        		<?php
        			include 'connect.php';
        			$count = mysqli_query($con,"SELECT * FROM aboutus");
					$num =mysqli_num_rows($count);
					$i=1;
					while ($num!=0) {
        			$sql="SELECT * FROM aboutus WHERE ID=$i";
        			$result = mysqli_query($con,$sql) or die("Error: " . mysqli_error($con));
                    while($row = mysqli_fetch_array($result)) {
        				echo $row['Name']."<br>";
        				echo $row['phone']."<br>"; ?>
        				<img src="mail.png" width="80px" class="mail">
        				<?php       			
        				echo $row['email']."<br>";
                        echo $row['qualification'];
        				echo "<br><br><br><br><br>";
        			}
        			$i=$i+1;
        			$num=$num-1;
        		}
        			mysqli_close($con)
        		?>
       		</div>

      </div>
 
	
</body>
</html>
