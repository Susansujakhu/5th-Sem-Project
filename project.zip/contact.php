
<!DOCTYPE html>
<html>
<head>
	<title>Contact page</title>

	<link rel="stylesheet" href="style.css">
</head>
<body>

        <div class="topright">
        <a href="../Project">  Home </a>
        <a href="service.php">  Services </a>
        <a href="contact.php"> Contact </a>
        <a href="../Project/#AboutUs">  About Us </a> 
</div>
</body>
</html>