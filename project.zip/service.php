
<!DOCTYPE html>
<html>
<head>
	<title>Our Services</title>
	<style type="text/css">
img{
  border-radius: 50%;
  border: 5px solid gray;
  height: 200px;
  width: 200px;
}
.lab{
 position: none;
  margin-top: 4%;
  margin-left: 25%;
	margin-right: 5%;
	text-align: justify;
}
.headd{
  font-weight: bolder;
  font-size: 30px;
  font-family: "Calibri";
  color: brown;
}
.headd::first-letter{
border-bottom: 3px solid; 
}


.uli{
  float: left;
	font-size: 20px;
	color:purple;
	margin-top: 50px;
	position: none;
	height: 40px;
	font-family: 'Calibri';
	margin-left: 5%;
	font-size: 60px;
	
	
}




.shead{
  position: none;
	margin-left: 13%;
	font-weight: bold;
	margin-top: 50px;
	height: 40px;
	font-family: 'Calibri';

	font-size: 60px;
	color:purple;

}
.shead::first-letter{
border-bottom: 3px solid; 
}



.description{
  float: left;
  height: auto;
	font-family: 'Calibri';
  letter-spacing: 1px;
  font-size: 20px;
  color: black;
  line-height: 30px;
  margin-left: 50px;
  margin-bottom: 5%;
}
.images{
  margin-left: 2%;
  margin-top: 4%;
  width: 2%;
  float: left;
 }
</style>

<link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>
<div class='contain'>
		<?php
		include 'menu.php';
		session_start();
		if(isset($_SESSION['uname']))
		{
    //  logged in
    		include 'ulogout.php';

    	}
    	else{
    		include 'ulogin.php';
    	}
		?>

<div class="uli">Our </div><div class='shead' > Services </div>

<div class='images'>  <center>

<?php
     include 'connect.php';
     $sql="SELECT * FROM `adminservice`";
     $cnt=mysqli_query($con,$sql);
     $n=mysqli_num_rows($cnt);
     for($i=1;$i<=$n;$i++){
     	$sqlimg="SELECT * FROM `adminservice` where id=$i";
     	$res=mysqli_query($con,$sqlimg);
     	while($row=mysqli_fetch_array($res)){
     		$image=$row['image'];
     		echo "<img src=$image><br><br>";

     	}
     }

	?>
</center>
</div>
<div class="lab" >
	
<?php
	
     include 'connect.php';  
      $sql="SELECT * FROM `adminservice`";
      $cnt=mysqli_query($con,$sql);
     $n=mysqli_num_rows($cnt);
     for($i=1;$i<=$n;$i++){
     	$sql="SELECT * FROM `adminservice` where id=$i";
     	$res=mysqli_query($con,$sql);
     	while($row=mysqli_fetch_array($res)){
        echo "<span class='headd'>";
     		echo $row['headd'];
     		echo  "</span><br><br>";
     		echo "<span class='description'>" ;
     		echo $row['description'];
     		echo "</span><br>";
		}
  }
	?>
</div>

	<?php
  /* include 'connect.php';    
     $sql="SELECT * FROM `adminservice`";
     $cnt=mysqli_query($con,$sql);
     $n=mysqli_num_rows($cnt);
     for($i=2;$i<=$n;$i++){
     	$sql="SELECT * FROM `adminservice` where id=$i";
     	$res=mysqli_query($con,$sql);
     		
     	while($row=mysqli_fetch_array($res)){
     		echo "<div class='head'><b>";
     		echo $row['headd'];
     		echo "</b><br><br>";
     		echo "<span class='description'>" ;
     		echo $row['description'];
     		echo "</span>";
     		echo "</div>";

		}
	  
	  }
	  */
	?>
	</div>
</body>
</html>

