<!DOCTYPE html>
<html>
<head>
	
	<title>Our Products</title>
	<link type="text/css" rel="stylesheet" href="style.css" >
</head>
<body>
	<div class="contain">

		<?php
		include 'menu.php';
		session_start();
		if(isset($_SESSION['uname']))
		{
    //  logged in
    		include 'ulogout.php';

    	}
    	else{
    		include 'ulogin.php';
    	}
		?>
		
	<div class="search">
<div class="dropdown">
  <button class="dropbtn">Category</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
		<input class='bar' type="text" name="search" placeholder="Search product here">
		<div class="icons">
		<a href="#"> <img class="spng" src="search.png" title="Search Product"></a>
		<a href="#"> <img class="apng" src="addtocart.png" title="Add to Cart"></a>
	</div>
	</div>
	<div class="pleft">
		<div class='pcategory'>
			<?php  
				include 'connect.php';
				$sql="SELECT * FROM products";
				$result=mysqli_query($con,$sql);
				while($row = mysqli_fetch_array($result)) {
					$p_category=$row['p_category'];
        			echo  "<input class='p_catabtn' type='button' name='mats' value='$p_category'>";
        			echo "<br>";
        		}	
				mysqli_close($con);
			?>
		</div>
	</div>
	<div class="pright">
		<div class="pright_top">
<div id="slideshow">
  <div class="slide-wrapper">
    <?php  
				include 'connect.php';
				$sql="SELECT * FROM products";
				$result=mysqli_query($con,$sql);
				while($row = mysqli_fetch_array($result)) {
					echo "<div class='slide'>";
					$p_img=$row['p_img'];
					echo "<img class='slideimg' src='$p_img'>";
					echo "</div>";
        		}	
				mysqli_close($con);
			?>
   </div>
</div>
		</div>
		
			<?php  
				include 'connect.php';
				$sql="SELECT * FROM products";
				$result=mysqli_query($con,$sql);
				while($row = mysqli_fetch_array($result)) {
					echo "<div class='p_right_bottom'>";
					$p_img=$row['p_img'];
					$p_price=$row['p_price'];
        			echo  "<a href=#><img class='p_img' src='$p_img'></a>";
        			echo "<div class='p_name'>";
        			echo $row['p_name'];
        			echo "</div>";
        			echo "<div class='p_right_txt'>";
        			echo $row['p_subdesc'];
        			echo "<a href=# class='show'>Show more</a>";
        			echo "<div class='p_price'>";
        			echo "Rs <a href=# class='p_price'>$p_price</a>";
        			echo "</div>";
        			echo "</div></div>";

        		}	
				mysqli_close($con);
			?>
		
	</div>
</div>
</body>
</html>