<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link type="text/css" rel="stylesheet" href="style.css" >
		<script type="text/javascript">
		function call(){
			var email=document.getElementById('email').value;
			var check = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
 			 if(!check.test(email)){
 			document.getElementById("error").innerHTML="**Invalid Email**";
 			return false;

 			 } 
			}
			
	</script>
<title>Registration Page</title>
</head>

<body>
<html>
<center> <h1> REGISTRATION </h1></center>
<form action="" method="post" enctype="multipart/form-data">
<table align="center" border="0" cellspacing="15px" cellpadding="5px">
	<tr>
<td><label class="forms"> First Name  </label></td>
<td><input class="txt" type="text" name="first_name" placeholder="First Name" required></td>

 <td><label class="forms"> Middle Name  </label> </td>
<td><input class="txt" type="text" name="middle_name" placeholder="Middle Name"> </td>
	</tr>
	<tr>
<td><label class="forms">Last Name  </label></td>
<td><input class="txt" type="text" name="last_name" placeholder="Last Name" required></td>
<td><label class="forms">Gender  </label></td>
<td><label class='gender'>Male</label>
<input class="radioo" type=radio name=ans1 value="M" required>
<label class="gender">
Female
</label>
<input class="radioo" type=radio name=ans1 value="F" required>
</td>
</tr>
<tr>	
	
<td><label class="forms">Permanent Address  </label></td>
<td><input class="txt" type="text" name="permanent" placeholder="Permanent Address"> </td>
	


<td><label class="forms">Temporary Address  </label></td>
<td><input class="txt" type="text" name="temporary" placeholder="Temporary Address" required></td>
	</tr>

	<tr>
<td><label class="forms">Contact No.</label></td>
<td><input class="txt" type="text" name="contact" placeholder="Contact No."></td>



<td><label class="forms">Mobile  </label></td>
<td><input class="txt" type="text" name="mobile" placeholder="Mobile" required></td> 
	</tr>
	<tr>

<td><label class="forms">Email  </label></td>
 <td><input class="txt" type="text" name="email" placeholder="Email" id='email' required></td>
<td><label class="forms">Photo  </label></td>
<td><input class="photo" type="file" name="img"> </td>
	</tr>
	<tr>
<td><label class="forms">Username  </label> </td>
<td><input class="txt" type="text" name="username" placeholder="Username" required> </td>


<td><label class="forms">Password  </label> </td>
 <td><input class="txt" type="password" name="password" placeholder="Password" required> </td>
 </tr>
 </table>
 <div class="buttons">
<input class="rsubmit" type="submit" name="submit" value="Submit" onclick="return call()"> 
<input class="rsubmit" type="button" name="cancel" value="Cancel" onclick="window.location.href = './';" formnovalidate> 
</div>

</form>

<body>
</html>
</body>
</html>

<?php
include 'connect.php';
if(isset($_POST['submit'])){
		$fname=$_POST['first_name'];
		$mname=$_POST['middle_name'];
		$lname=$_POST['last_name'];
		$gender=$_POST['ans1'];
		$p_add=$_POST['permanent'];
		$t_add=$_POST['temporary'];
		$contact=$_POST['contact'];
		$mobile=$_POST['mobile'];
		$email=$_POST['email'];
		$username=$_POST['username'];
		$password=$_POST['password'];
		$photo=$_FILES['img']['name'];

		$sql="INSERT INTO `customer` VALUES ('c_id','$fname','$mname','$lname','$gender','$p_add','$t_add','$contact','$mobile','$email','$username','$password','$photo')";
		if(mysqli_query($con,$sql)){
				echo "<script type='text/javascript'>";
				echo "alert('Registration Successful Thankyou $fname $lname')";
				echo "</script>";

	}
	else{
				echo "<script type='text/javascript'>";
				echo "alert('Registration Failed')";
				echo "</script>";
	}
}
mysqli_close($con);
?>

