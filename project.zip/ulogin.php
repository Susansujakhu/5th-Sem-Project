<html>
<head>
<script type="text/javascript">

var popupWindow=null;

function child_open()
{ 

popupWindow =window.open('forget.php',"_blank","directories=no, status=no, menubar=no, scrollbars=yes, resizable=no,width=600, height=280,top=200,left=200");

}
function parent_disable() {
if(popupWindow && !popupWindow.closed)
popupWindow.focus();
}
</script>
</head>
<body onclick="parent_disable();">
    <div class="topper">
			<div class="forget">
				<a href="javascript:child_open()">Forgot Password?</a>
			</div>
			<form method="post" action="">	
				<input class="input-field" type="text" name="logemail" placeholder="Username" required="">
				<input class="input-field" type="password" name="logpass" placeholder="Password" required="">
				<input class="btn" type="submit" name="login" value="Login">
				<input class="btn" type="button" name="register" value="Register" onclick="window.location.href = 'register.php';" formnovalidate>
			</form>
		</div>
</body>    
</html>

<?php

if(isset($_POST['login'])){
	$user=$_POST['logemail'];
	$pass=$_POST['logpass'];
	include 'connect.php';
	$sql="SELECT Username,Password FROM customer";
	$result=mysqli_query($con,$sql);
	$num=mysqli_num_rows($result);
		for ($i=$num; $i >= 0; $i--) { 
			$row=mysqli_fetch_array($result);
			$duser=$row['Username'];
			$dpass=$row['Password'];
			if($user==$duser && $pass==$dpass && $i>0){
				$_SESSION['uname']=$user;
				$_SESSION['upass']=$pass;
				//end:header('location:./');
			}
			elseif ($i==0){
				echo "<script type='text/javascript'>";
				echo "alert('Please Enter valid username and password!')";
				echo "</script>";	
				break;
				}
			}		
}
?>